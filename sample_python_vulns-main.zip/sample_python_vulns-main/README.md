# Common Python Coding Mistakes: How They Can Cause Vulnerabilities and How to Solve Them! 

This contains some samples that are part of a presentation and [blog post](https://blogs.cisco.com/developer/pythonvulnerabilities01).

> **Note:** this code is vulnerable and dangerous and should only be used for demo purposes!
